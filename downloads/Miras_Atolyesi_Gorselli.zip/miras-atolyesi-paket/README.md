# Projeler

[Miras Atölyesi · Teldeki Sevda](miras-atolyesi/README.md) oyununun bütün kaynakları **miras-atolyesi/** klasöründedir. Bu klasör, önceki oyun dosyaları korunarak hazırlanmıştır.

**Hazır paketi kullanmak için:** ZIP'i bir klasöre çıkarın ve kökteki **index.html** dosyasını tarayıcınızda açın. İki özgün görsel, yazı stilleri, oyun kodu ve sözcük denetimi bu dosyanın içindedir. Görsel eklemek veya dosya yolu düzenlemek gerekmez.

Tarayıcınız yerel HTML açılmasını kısıtlıyorsa veya geliştirme sunucusu kullanmak istiyorsanız:

```sh
python3 miras-atolyesi/scripts/serve.py
```

Python 3.10+ yeterlidir; paket kurulumu gerekmez. Node.js varsa `npm start` da kullanılabilir. Varsayılan port 4173'tür; `--port 8080` ile değiştirilebilir. Kaynaklar güncellendiğinde sunucu başlangıçta tek dosyalık oyun girişini yeniden oluşturur.

**index.html**, önizleme araçları için CSS ve JavaScript'i içinde taşıyan oyun çıktısıdır. Oyun klasöründeki index.html ile aynıdır; doğrudan yerel tarayıcıda da açılabilir. Depo kökündeki kopyayı yenilemek için `python3 miras-atolyesi/scripts/build.py --repo-entry` çalıştırın. HTML/CSS/JS kaynaklarının tümü oyun klasöründe ayrıca saklanır.

**Özgün giriş ve giriş sonrası görselleri pakete eklenmiştir.** Görseller değiştirilmeden HTML içine gömülür; ayrı bir görsel yükleme veya JSON düzenleme işlemi gerekmez. [Görsel yönergeleri](miras-atolyesi/assets/README.md).

Güncel sürümde isim ve yanıt geri bildirimleri ortadaki pencerelerde açılır. Büyük parşömende sorular, sağ üstte ilham telleri bulunur. Noktalama sorusunda yalnızca iki kutu düzenlenebilir; yaratıcı dize tek satırdır. Finalde Tekrar Oyna bulunur. Oyunun içinde indirme, ayar veya ses düğmesi yoktur. Türkçe kök/ek ve uygunsuz ifade denetimleri çevrimdışı çalışır.

[Test sonuçları](miras-atolyesi/docs/TEST-SONUCLARI.md)
